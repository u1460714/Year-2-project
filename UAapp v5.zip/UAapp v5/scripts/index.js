﻿




function move() {
    var elem = document.getElementById("myBar");
    var width = 10;
    var id = setInterval(frame, 20);
    function frame() {
        if (width >= 88) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            document.getElementById("label").innerHTML = width * 1 + '%';
        }
    }
}

function move1() {
    var elem = document.getElementById("myBar1");
    var width = 10;
    var id = setInterval(frame, 20);
    function frame() {
        if (width >= 70) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            document.getElementById("label1").innerHTML = width * 1 + '%';
        }
    }
}


function validateLogin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var usernameValue = username.valueOf;
    var loggedIn = false;

    if (username === "") {
        alert("Please insert username");
        window.location = "login.html"
    }

    if (username === "u1460714" & password === "barney") {
        alert("Login Successful");
        window.location = "scan.html";
        loggedIn = true;
    }

    if (username[0] !== "u") {
        alert("Username must start with 'u'");
        window.location = "login.html";
    }

    if (username.length > 8)
    {
        alert("Usernames are no longer than 8 characters");
        window.location = "login.html";
    }

    if (String.length(username) !== 8) {
        alert("Username must be 8 characters in length")
    }
}