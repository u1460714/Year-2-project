﻿

function toggleTable() {
    var elem = document.getElementById("loginTable");
    var hide = elem.style.display == "none";
    if (hide) {
        elem.style.display = "table";
    }
    else {
        elem.style.display = "none";
    }
}




function move() {
    var elem = document.getElementById("myBar");
    var width = 10;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 88) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            document.getElementById("label").innerHTML = width * 1 + '%';
        }
    }
}

function move1() {
    var elem = document.getElementById("myBar1");
    var width = 10;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 70) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            document.getElementById("label1").innerHTML = width * 1 + '%';
        }
    }
}


function enagagementincrease() {
    var elem = document.getElementById("myBar1");
    var width = 10;
    var id = setInterval(frame, 30);
    function frame() {
        if (width >= 73) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            document.getElementById("label1").innerHTML = width * 1 + '%';
        }
    }
}

function move2() {
    var elem = document.getElementById("myBar2");
    var width = 10;
    var id = setInterval(frame, 20);
    function frame() {
        if (width >= 100) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            document.getElementById("label2").innerHTML = width * 1 + '%';
        }
    }
}


function showalert(id) {
        var divelement = document.getElementById(id);
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        if (username === "") {
            document.getElementById("alertmsg").innerHTML = "You didn't insert a username!";
            divelement.style.display == 'none'
            divelement.style.display = 'block';
        }

        if (password === "") {
            document.getElementById("alertmsg").innerHTML = "You didn't insert a password!";
            divelement.style.display == 'none'
            divelement.style.display = 'block';
        }

        if (password === "" && username === "") {
            document.getElementById("alertmsg").innerHTML = "You didn't insert a username or password!";
            divelement.style.display == 'none'
            divelement.style.display = 'block';
        }

        if (username === "u1460714" && password === "") {
            document.getElementById("alertmsg").innerHTML = "Please enter your password!";
            divelement.style.display == 'none'
            divelement.style.display = 'block';
        }

        else if (username.length > 8) {
            document.getElementById("alertmsg").innerHTML = "Student usernames are only 8 characters!";
            divelement.style.display == 'none'
            divelement.style.display = 'block';
        }
 

      
            if (username === "u1460714" && password === "barney") {
                document.getElementById("alertmsg").innerHTML = "Successfully logged in, redirecting in 3 seconds";
                setTimeout(function() {
                    window.location = "attendance.html";
                }, 3000);
                divelement.style.display = 'block';
                divelement.className = 'success'
            }
        }

function scanalertfunction(id) {
    var divelement1 = document.getElementById(id)

    document.getElementById("scanalertmsg").innerHTML = "Scan Failed!";
    divelement1.style.display == 'none'
    divelement1.style.display = 'block';
}


function scanalertfunctionsuc(id) {
    var divelement2 = document.getElementById(id)

    document.getElementById("scanalertmsgsuc").innerHTML = "Scan in Successful!";
    divelement2.style.display == 'none'
    divelement2.style.display = 'block';
}




// attendance page //
function toggleTable() {
    var elem = document.getElementById("loginTable");
    var hide = elem.style.display == "none";
    if (hide) {
        elem.style.display = "table";
    }
    else {
        elem.style.display = "none";
    }
}


function toggleButton() {
    var elem = document.getElementById("checkbox123");
    var hide = elem.style.display == "none";
    if (hide) {
        elem.style.display = "input";
    }
    else {
        elem.style.display = "none";
    }
}


function loadtable(id) {
    var divelement = document.getElementById(id);

    if (divelement.style.display == 'none')
        divelement.style.display = 'block';
    else
        divelement.style.display = 'none';
}

function hidediv(id) {
    var divelement = document.getElementById(id);

    if (divelement.style.display == 'none')
        divelement.style.display = 'block';
    else
        divelement.style.display = 'none';
}

function hidediv1(id) {
    var divelement = document.getElementById(id);

    if (divelement.style.display == 'none')
        divelement.style.display = 'block';
    else
        divelement.style.display = 'none';
}

function hidediv2(id) {
    var divelement = document.getElementById(id);

    if (divelement.style.display == 'none')
        divelement.style.display = 'block';
    else
        divelement.style.display = 'none';
}


function hidediv4(id) {
    var divelement = document.getElementById(id);

    if (divelement.style.display == 'none')
        divelement.style.display = 'block';
    else
        divelement.style.display = 'none';
}

function check() {
    document.getElementById("checksubmitvalue").disabled = true;
    var val = document.getElementById('absence').value;
    if (val == 'disable') {
        document.getElementById('checksubmitvalue').disabled = true;
    } else {
        document.getElementById('checksubmitvalue').disabled = false;
    }
}

function scanhelpfunction(id) {
    var alertmsg = document.getElementById(id)
    document.getElementById("scanhelpmsg").innerHTML = "Below is some guidance if you are having difficulty scanning in";
    document.getElementById("p1").innerHTML = "-Make sure you...";
    document.getElementById("p2").innerHTML = "Press start before scanning";
    document.getElementById("p3").innerHTML = "Hold the barcode to the scanner for 5 seconds";
    document.getElementById("p4").innerHTML = "A notification will appear informing you if the scan succeeded."
    document.getElementById("p5").innerHTML = "Contact Student Support at student.support@hud.ac.uk"
    document.getElementById("p6").innerHTML = "Contact the App team if you believe they is an issue UAapp@hud.ac.uk"
    alertmsg.style.display == 'none'
    alertmsg.style.display = 'block';
}





//

function messengerfunction(id) {
    var messengeralertmsg = document.getElementById(id)
    messengeralertmsg.style.display == 'none'
    messengeralertmsg.style.display = 'block';
}

function messengerchatfunction(id) {
    var chatmsg = document.getElementById(id)
    chatmsg.style.display == 'none'
    chatmsg.style.display = 'block';
}

function messengerchatfunctiontext(id) {
    var textboxmsg = document.getElementById("textboxmsg").value
    document.getElementById("messengerchatp").innerHTML = textboxmsg;
}

function addfriendfunction(id) {
    var friendcontent = document.getElementById(id)
    var friendname = document.getElementById("textboxmessenger").value;

    friendcontent.style.display == 'none'
    friendcontent.style.display = 'block';
}



function scanalertfunctionsuc(id) {
    var divelement2 = document.getElementById(id)

    document.getElementById("scanalertmsgsuc").innerHTML = "Scan in Successful!";
    divelement2.style.display == 'none'
    divelement2.style.display = 'block';
}

function showfriendfunction(id) {
    var showdiv = document.getElementById(id)
    showdiv.style.display == 'none'
    showdiv.style.display = 'block';
}

function accordiontoggle() {
    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        acc[i].onclick = function () {
            this.classList.toggle("active");
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            }
        }
    }
}

function friendrequestsent(id) {
    var textboxmsg = document.getElementById("textboxmessenger").value
    var textboxmsg2 = document.getElementById("textboxmessenger2").value
    var showdiv = document.getElementById(id)
    showdiv.style.display == 'none'
    showdiv.style.display = 'block';
    document.getElementById("friendrequestcontainerp1").innerHTML = textboxmsg;
    document.getElementById("friendrequestcontainerp2").innerHTML = textboxmsg2;
}


function friendblocked(id) {
    var textboxmsg = document.getElementById("textboxblock1").value
    var textboxmsg2 = document.getElementById("textboxblock2").value
    var showdiv = document.getElementById(id)
    showdiv.style.display == 'none'
    showdiv.style.display = 'block';
    document.getElementById("blockusername1").innerHTML = textboxmsg;
    document.getElementById("blockusername2").innerHTML = textboxmsg2;
}

